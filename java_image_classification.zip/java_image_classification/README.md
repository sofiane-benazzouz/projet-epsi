# Convolutional Neural Network (CNN)- Image Classification using Java and Deeplearning4j 

## Prerequisites:
1. JDK 1.8
2. Deeplearning4j
3. Maven

## Steps to run the project:
1. Run command "mvn clean install package" in the root of the project
2. Run comman java -jar java_dl4j_image_classification-0.0.1-SNAPSHOT.jar